#include "ex14_07.h"

int main()
{
    String str("Hello World");
    std::cout << str << std::endl;
}
