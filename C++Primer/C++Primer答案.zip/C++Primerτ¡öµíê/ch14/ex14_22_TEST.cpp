#include "ex14_22.h"

int main()
{
    std::string strCp5("C++ Primer 5th");
    Sales_data cp5;
    cp5 = strCp5;
    std::cout << cp5 << std::endl;
}
